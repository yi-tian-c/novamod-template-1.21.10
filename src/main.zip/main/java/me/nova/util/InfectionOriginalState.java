package me.nova.util;

import com.mojang.serialization.Codec;
import net.minecraft.datafixer.DataFixTypes;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.world.PersistentState;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.datafixer.DataFixTypes;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtOps;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.PersistentState;
import net.minecraft.world.PersistentStateType;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

public class InfectionOriginalState extends PersistentState {
    private static final Codec<Map<String, BlockState>> STATES_CODEC =
            Codec.unboundedMap(Codec.STRING, BlockState.CODEC);

    public static final Codec<InfectionOriginalState> CODEC =
            STATES_CODEC.xmap(
                    InfectionOriginalState::new,
                    state -> state.originalStates
            );

    public static final PersistentStateType<InfectionOriginalState> TYPE =
            new PersistentStateType<>(
                    "novamod_infection_original_states",
                    InfectionOriginalState::new,
                    CODEC,
                    DataFixTypes.LEVEL
            );

    private final Map<String, BlockState> originalStates;

    public InfectionOriginalState() {
        this.originalStates = new HashMap<>();
    }

    private InfectionOriginalState(Map<String, BlockState> states) {
        this.originalStates = new HashMap<>(states);
    }

    public static InfectionOriginalState get(ServerWorld world) {
        return world.getPersistentStateManager().getOrCreate(TYPE);
    }

    private String key(BlockPos pos) {
        return Long.toString(pos.asLong());
    }

    public void saveOriginal(BlockPos pos, BlockState original) {
        String key = key(pos);

        if (!originalStates.containsKey(key)) {
            originalStates.put(key, original);
            markDirty();
        }
    }

    public Optional<BlockState> getOriginal(BlockPos pos) {
        return Optional.ofNullable(originalStates.get(key(pos)));
    }

    public void removeOriginal(BlockPos pos) {
        if (originalStates.remove(key(pos)) != null) {
            markDirty();
        }
    }
}